import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cloud-resume-challenge-2')

def lambda_handler(event, context):
    response = table.get_item(Key={
        'Id':'1'
    })
    
    visits = response['Item']['visits']
    visits = visits + 1
    print(visits)
    
    response = table.put_item(Item={
        'Id':'1',
        'visits': visits
    })
    
    return visits